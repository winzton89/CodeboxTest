# Service B - Load Generator (bot.js)

## Overview

This service acts as a load generator that continuously sends requests to Service A (server.js) to simulate different traffic loads. The bot uses Axios to send HTTP requests at a specified interval.

## Prerequisites

- Node.js installed
- Service A (server.js) running on http://localhost:3000

## Installation & Setup

Since using Google Drive instead of GitHub, follow these steps:

1. Clone or Download this project.
2. Navigate to the Service B directory in your terminal:
   ```cd path/to/service-b
   ```
3. Install required dependencies:
   ```npm install axios
   ```

## Configuration

Modify bot.js for custom behavior:

- Target Service A URL: Change SERVICE_A_URL = 'http://localhost:3000' if needed.
- Request Interval: Adjust REQUEST_INTERVAL_MS = 15000 (in milliseconds) for different traffic loads.
  - Example: 500ms for high traffic, 15000ms for low traffic.

## Running the Bot

To start sending requests to Service A, run:
```node bot.js
```

## Expected Output

If Service A is running correctly, you should see logs like:
```[INFO] Sending request to Service A...
[INFO] Received response: 200 OK
```

## Expected Behavior

- The bot logs responses from Service A.
- If Service A is down, it logs an error.
- The bot runs indefinitely until manually stopped (CTRL + C).

## Troubleshooting

- Error: Connection refused → Ensure server.js (Service A) is running.
- CORS issue → Ensure Service A has CORS enabled.

## Notes

This is a simple implementation. You can enhance it with concurrency or randomized load patterns.


