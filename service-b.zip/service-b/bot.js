const axios = require('axios');  // To send HTTP requests
const http = require('http');    // To create a simple HTTP server
const delay = ms => new Promise(resolve => setTimeout(resolve, ms)); // Helper to add delay

// Configuration
const serviceAUrl = 'http://localhost:3000';  // Service A endpoint
const requestRate = 1000;  // Requests per second
const maxRequests = 1000;  // Max number of requests to send (optional)

// Function to send requests
async function sendRequest() {
  try {
    const response = await axios.get(serviceAUrl);  // Sending a GET request to Service A
    console.log(`Request sent to ${serviceAUrl}, Status: ${response.status}`);
  } catch (error) {
    console.error(`Error sending request: ${error}`);
  }
}

// Function to simulate traffic load
async function simulateTraffic() {
  let sentRequests = 0;
  while (sentRequests < maxRequests) {
    await sendRequest();
    sentRequests++;
    await delay(1000 / requestRate);  // Sending requests at the specified rate
  }
}

// Start the bot
simulateTraffic();
